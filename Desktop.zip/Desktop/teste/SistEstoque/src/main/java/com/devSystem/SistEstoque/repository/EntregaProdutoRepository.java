package com.devSystem.SistEstoque.repository;

import com.devSystem.SistEstoque.model.EntregaProduto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntregaProdutoRepository extends JpaRepository<EntregaProduto, Long> {
}
