let cadEntrega = document.getElementById('cadEntrega')
let listaEntregas = document.getElementById('listaEntregas')
let buscaEntrega = document.getElementById('buscaEntrega')
let res1 = document.getElementById('res1')
let res2 = document.getElementById('res2')
let res3 = document.getElementById('res3')

cadEntrega.addEventListener('click',()=>{
    res1.innerHTML = ""

    let nomeProdutoEntrega = document.getElementById('nomeProdutoEntrega').value
    let quantidadeEntrega = document.getElementById('quantidadeEntrega').value
    let dataEntrega = document.getElementById('dataEntrega').value
    let responsavelEntrega = document.getElementById('responsavelEntrega').value
    let funcionarioId = document.getElementById('funcionarioId').value
    let estoqueId = document.getElementById('estoqueId').value

    const dados = {
        nomeProdutoEntrega : nomeProdutoEntrega,
        quantidadeEntrega : quantidadeEntrega,
        dataEntrega : dataEntrega,
        responsavelEntrega : responsavelEntrega,
        funcionarioId : funcionarioId,
        estoqueId : estoqueId
    }

    fetch('http://localhost:8080/entrega',{
        method: "POST",
        headers:{ "Content-Type":"application/json"},
        body: JSON.stringify(dados)
    })
    .then(resposta => resposta.json())
    .then(dados => {
        console.log(dados)
        res1.innerHTML = "Entrega cadastrada com sucesso!"
    })
    .catch((err)=> console.error('Erro ao cadastrar entrega!',err))
})
listaEntregas.addEventListener('click',()=>{
    res2.innerHTML = ""
    fetch('http://localhost:8080/entrega')
    .then(resposta => resposta.json())
    .then(dados => {
        res2.innerHTML = "<ul>"
        dados.forEach(valor => {
            console.log(valor)
            res2.innerHTML += "<li> Código: " + valor.codEntrega + "&emsp;" +
                              "Nome: " + valor.nomeProdutoEntrega + "&emsp;" +
                              "Quantidade: " + valor.quantidadeEntrega + "&emsp;" +
                              "Data: " + valor.dataEntrega + "&emsp;" +
                              "Responsavel: " + valor.responsavelEntrega + "&emsp;" +
                              "ID do funcionário: " + valor.funcionarioId + "&emsp;" +
                              "ID do estoque: " + valor.estoqueId 
        }) 

    })
    .catch((err) => console.error('Erro ao listar entregas!',err))
})
buscaEntrega.addEventListener('click',()=>{
    res3.innerHTML = ""
    const codEntregaBusca = Number(document.getElementById('codEntregaBusca').value)

    fetch(`http://localhost:8080/entrega/${codEntregaBusca}`)
    .then(resposta => resposta.json())
    .then(dados => {
        res3.innerHTML += "Código: " + dados.codEntrega + "&emsp;" +
        "Nome: " + dados.nomeProdutoEntrega + "&emsp;" +
        "Quantidade: " + dados.quantidadeEntrega + "&emsp;" +
        "Data: " + dados.dataEntrega + "&emsp;" +
        "Responsavel: " + dados.responsavelEntrega + "&emsp;" +
        "ID do funcionário: " + dados.funcionarioId + "&emsp;" +
        "ID do estoque: " + dados.estoqueId 

    })
    .catch((err)=> console.error('Erro ao buscar entregas!',err))
})

function apareca(option) {
    for(let i=1; i < 6;i++) {
        if(i == option ) {
            document.getElementById(`res${i}`).style.display = 'block'
        }else {
            document.getElementById(`res${i}`).style.display = 'none'
        }
    } 
}