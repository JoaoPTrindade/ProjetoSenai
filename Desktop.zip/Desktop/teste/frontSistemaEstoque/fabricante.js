let cadFabricante = document.getElementById('cadFabricante')
let listaFabricantes = document.getElementById('listaFabricantes')
let buscaFabricante = document.getElementById('buscaFabricante')
let atualizaFabricante = document.getElementById('atualizaFabricante')
let deletaFabricante = document.getElementById('deletaFabricante')
let res1 = document.getElementById('res1')
let res2 = document.getElementById('res2')
let res3 = document.getElementById('res3')
let res4 = document.getElementById('res4')
let res5 = document.getElementById('res5')

cadFabricante.addEventListener('click',()=>{
    res1.innerHTML = ""
    let nomeFabricante = document.getElementById('nomeFabricante').value
    let codFuncionario = document.getElementById('codFuncionario').value

    const dados = {
        codFuncionario:codFuncionario,
        nomeFabricante:nomeFabricante
    }
    fetch("http://localhost:8080/fabricante",{
        method: "POST",
        headers:{ "Content-Type":"application/json"},
        body: JSON.stringify(dados)
    })
    .then(resposta => resposta.json())
    .then(dados => {
        console.log(dados)
        res1.innerHTML += "Fabricante cadastrado!"
    })
    .catch((err)=> console.error("Erro ao cadastrar fabricante: ",err))
})
listaFabricantes.addEventListener('click',()=>{
    res2.innerHTML = ""
    fetch("http://localhost:8080/fabricante")
    .then(resposta => resposta.json())
    .then(dados => {
        console.log(dados)
        res2.innerHTML += "<ul>"
        dados.forEach(valor => {
            res2.innerHTML += "<li>Código do fabricante: " + valor.codFabricante + "&emsp;" +
                             "Nome do fabricante: " + valor.nomeFabricante + "&emsp;" +
                             "Código do funcionário: " + valor.codFuncionario + "<br>"
        })
    })
    .catch((err)=>console.error("Erro ao atualizar fabricante: ",err))
})
buscaFabricante.addEventListener('click',()=>{
    res3.innerHTML = ""
    const idBusca = Number(document.getElementById('codFabricanteBusca').value)

    fetch(`http://localhost:8080/fabricante/${idBusca}`)
    .then(resposta => resposta.json())
    .then(dados => {
        res3.innerHTML += "Código do fabricante: " + dados.codFabricante + "&emsp;" +
                          "Nome do fabricante: " + dados.nomeFabricante + "&emsp;" +
                          "Código do funcionário: " + dados.codFuncionario + "<br>"
    })
    .catch((err)=> console.error("Erro ao buscar fabricante: ",err))

})
atualizaFabricante.addEventListener('click',()=>{
    res4.innerHTML = ""
    const idAtualiza = Number(document.getElementById('codFabricanteAtualiza').value)

    const nomeFabricante = document.getElementById('nomeFabricanteAtualizado').value
    const codFuncionario = document.getElementById('codFuncionarioAtualizado').value

    const dados = {
        nomeFabricante: nomeFabricante,
        funcionarioId: codFuncionario
    }
    fetch(`http://localhost:8080/fabricante/${idAtualiza}`,{
        method: "PUT",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(dados)
    })
    .then(resposta => resposta.json())
    .then(dados => {
        res4.innerHTML = "Dados do fabricante atualizados!" + "<br>"
    })
    .catch((err)=> console.error("Erro ao atualizar fabricante: ",err))
})
deletaFabricante.addEventListener('click',()=>{
    res5.innerHTML = ""
    const idDeleta = Number(document.getElementById('codFabricanteDeleta').value)

    fetch(`http://localhost:8080/fabricante/${idDeleta}`,{
        method: "DELETE",
        headers: {"Content-Type":"application/json"}
    })
    .then(resposta => resposta.text())
    .then(dados => {
        res5.innerHTML = "Dados do fabricante excluidos!" + "<br>" + "<br>"
    })
    .catch((err)=> console.error("Erro ao deletar fabricante: ",err))
})

function apareca(option) {
    for(let i=1; i < 6;i++) {
        if(i == option ) {
            document.getElementById(`res${i}`).style.display = 'block'
        }else {
            document.getElementById(`res${i}`).style.display = 'none'
        }
    } 
}