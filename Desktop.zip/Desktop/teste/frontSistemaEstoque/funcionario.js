let cadFuncionario = document.getElementById("cadFuncionario")
let listaFuncionarios = document.getElementById("listaFuncionarios")
let buscaFuncionario = document.getElementById("buscaFuncionario")
let atualizaFuncionario = document.getElementById("atualizaFuncionario")
let deletaFuncionario = document.getElementById("deletaFuncionario")
let res1 = document.getElementById("res1")
let res2 = document.getElementById("res2")
let res3 = document.getElementById("res3")
let res4 = document.getElementById("res4")
let res5 = document.getElementById("res5")

cadFuncionario.addEventListener('click',()=>{
    res1.innerHTML = ""
    let nomeFuncionario = document.getElementById('nomeFuncionario').value
    let cpfFuncionario = document.getElementById('cpfFuncionario').value
    let cargoFuncionario = document.getElementById('cargoFuncionario').value
    let telefoneFuncionario = document.getElementById('telefoneFuncionario').value
    let situacaoFuncionario = document.getElementById('situacaoFuncionario').value

    const dados = {
        nomeFuncionario: nomeFuncionario,
        cpfFuncionario: cpfFuncionario,
        cargoFuncionario: cargoFuncionario,
        telefoneFuncionario: telefoneFuncionario,
        situacaoFuncionario: situacaoFuncionario
    }
    fetch("http://localhost:8080/funcionario",{
        method: "POST",
        headers:{ "Content-Type":"application/json"},
        body: JSON.stringify(dados)
    })
    .then(resposta => resposta.json())
    .then(dados => {
        console.log(dados)
        res1.innerHTML += "Funcionário cadastrado!"
    })
    .catch((err)=> console.error("Erro ao cadastrar funcionário: ",err))
})
listaFuncionarios.addEventListener('click',()=>{
    fetch("http://localhost:8080/funcionario")
    .then(resposta => resposta.json())
    .then(dados => {
        console.log(dados)
        res2.innerHTML = ""
        dados.forEach(valor => {
            res2.innerHTML += "<li>Código: " + valor.codFuncionario + "&emsp;" +
                              "Nome: " + valor.nomeFuncionario + "&emsp;" +
                              "CPF: " + valor.cpfFuncionario + "&emsp; <br>" +
                              "Cargo: " + valor.cargoFuncionario + "&emsp;" +
                              "Telefone: " + valor.telefoneFuncionario + "&emsp;" +
                              "Situação: " + valor.situacaoFuncionario + "<br>"
        })
        res2.innerHTML += "</ul>"
        res2.style.fontSize = "1.4rem"
        res2.style.fontWeight = "bold"

    })
    .catch((err)=> console.error("Erro ao listar funcionários: ",err))
})
buscaFuncionario.addEventListener('click',()=>{
    res3.innerHTML = ""
    const idBusca = Number(document.getElementById('codFuncionarioBusca').value)

    fetch(`http://localhost:8080/funcionario/${idBusca}`)
    .then(resposta => resposta.json())
    .then(dados => {
        res3.innerHTML += "Código: " + dados.codFuncionario + "&emsp;" +
                          "Nome: " + dados.nomeFuncionario + "&emsp;" +
                          "CPF: " + dados.cpfFuncionario + "&emsp;" +
                          "Cargo: " + dados.cargoFuncionario + "&emsp;" +
                          "Telefone: " + dados.telefoneFuncionario + "&emsp;" +
                          "Situação: " + dados.situacaoFuncionario + "<br>"
    })
    .catch((err)=> console.error("Erro ao buscar funcionários: ",err))
})
atualizaFuncionario.addEventListener('click',()=>{
    res4.innerHTML = ""
    const idAtualiza = Number(document.getElementById('codFuncionarioAtualiza').value)

    const nomeFuncionario = document.getElementById('nomeFuncionarioAtualizado').value
    const cpfFuncionario = document.getElementById('cpfFuncionarioAtualizado').value
    const cargoFuncionario = document.getElementById('cargoFuncionarioAtualizado').value
    const telefoneFuncionario = document.getElementById('telefoneFuncionarioAtualizado').value
    const situacaoFuncionario = document.getElementById('situacaoFuncionarioAtualizado').value

    const dados = {
        nomeFuncionario: nomeFuncionario,
        cpfFuncionario: cpfFuncionario,
        cargoFuncionario: cargoFuncionario,
        telefoneFuncionario: telefoneFuncionario,
        situacaoFuncionario: situacaoFuncionario
    }
    fetch(`http://localhost:8080/funcionario/${idAtualiza}`,{
        method: "PUT",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(dados)
    })
    .then(resposta => resposta.json())
    .then(dados => {
        res4.innerHTML = "Dados do funcionário atualizados!"
    })
    .catch((err)=> console.error("Erro ao atualizar dados: ",err))
})
deletaFuncionario.addEventListener('click',()=>{
    res5.innerHTML = ""
    const idDeleta = Number(document.getElementById('codFuncionarioDeleta').value)

    fetch(`http://localhost:8080/funcionario/${idDeleta}`,{
        method: "DELETE",
        headers: {"Content-Type":"application/json"}
    })
    .then(resposta => resposta.text())
    .then(dados => {
        res5.innerHTML = "Dados do funcionário apagados!" + "<br>" + "<br>"
    })
    .catch((err) => console.error("Erro ao apagar dados: ",err))
})

function apareca(option) {
    for(let i=1; i < 6;i++) {
        if(i == option ) {
            document.getElementById(`res${i}`).style.display = 'block'
        }else {
            document.getElementById(`res${i}`).style.display = 'none'
        }
    } 
}