let cadProduto = document.getElementById('cadProduto')
let listaProdutos = document.getElementById('listaProdutos')
let res1 = document.getElementById('res1')
let res2 = document.getElementById('res2')


cadProduto.addEventListener('click',()=>{
    res1.innerHTML = ""

    let nomeProduto = document.getElementById('nomeProduto').value
    let descricaoProduto = document.getElementById('descricaoProduto').value
    let quantidadeProduto = document.getElementById('quantidadeProduto').value
    let valorProduto = document.getElementById('valorProduto').value
    let validadeProduto = document.getElementById('validadeProduto').value
    let codEstoque = document.getElementById('codEstoque').value
    let codDoador = document.getElementById('codDoador').value
    let codFabricante = document.getElementById('codFabricante').value
    let codFuncionario = document.getElementById('codFuncionario').value

    const dados = {
        nomeProduto: nomeProduto,
        descricaoProduto: descricaoProduto,
        quantidadeProduto: quantidadeProduto,
        valorProduto: valorProduto,
        validadeProduto: validadeProduto,
        estoqueId: codEstoque,
        doadorId: codDoador,
        fabricanteId: codFabricante,
        funcionarioId: codFuncionario
    }

    fetch("http://localhost:8080/produto",{
        method: "POST",
        headers:{ "Content-Type":"application/json"},
        body: JSON.stringify(dados)
    })
    .then(resposta => resposta.json())
    .then(dados => {
        console.log(dados)
        res1.innerHTML = "Produto cadastrado!"
    })
    .catch((err)=> console.error('Erro ao cadastrar produto: ',err))
})
listaProdutos.addEventListener('click',()=>{
    res2.innerHTML = ""
    fetch("http://localhost:8080/produto")
    .then(resposta => resposta.json())
    .then(dados => {
        res2.innerHTML = "<ul>"
        dados.forEach(valor => {
            console.log(valor)
            res2.innerHTML += "<li>Código: " + valor.codProduto + "&emsp;" +
                              "Nome: " + valor.nomeProduto + "&emsp;" +
                              "Descrição: " + valor.descricaoProduto + "&emsp;" +
                              "Quantidade: " + valor.quantidadeProduto + "&emsp;" +
                              "Valor: R$" + valor.valorProduto + "&emsp;" +
                              "Validade: " + valor.validadeProduto + "<br>" +
                              "Código do estoque: " + valor.estoqueId + "&emsp;" +
                              "Código do doador: " + valor.doadorId + "&emsp;" +
                              "Código do fabricante: " + valor.fabricanteId + "&emsp;" +
                              "Código do funcionário: " + valor.funcionarioId + "<br>" + "<br>"
        })
    })
    .catch((err) => console.error("Erro ao listar doadores: ",err))
})

function apareca(option) {
    for(let i=1; i < 6;i++) {
        if(i == option ) {
            document.getElementById(`res${i}`).style.display = 'block'
        }else {
            document.getElementById(`res${i}`).style.display = 'none'
        }
    } 
}