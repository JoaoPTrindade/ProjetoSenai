let cadDoador = document.getElementById('cadDoador')
let listaDoadores = document.getElementById('listaDoadores')
let buscaDoador = document.getElementById('buscaDoador')
let atualizaDoador = document.getElementById('atualizaDoador')
let deletaDoador = document.getElementById('deletaDoador')
let res = document.getElementById('res')
let res2 = document.getElementById('res2')
let res3 = document.getElementById('res3')
let res4 = document.getElementById('res4')
let res5 = document.getElementById('res5')

cadDoador.addEventListener('click',()=>{
    res.innerHTML = ""
    let nomeDoador = document.getElementById('nomeDoador').value
    let cpfDoador = document.getElementById('cpfDoador').value
    let cnpjDoador = document.getElementById('cnpjDoador').value
    let emailDoador = document.getElementById('emailDoador').value
    let telefoneDoador = document.getElementById('telefoneDoador').value
    let enderecoDoador = document.getElementById('enderecoDoador').value
    let situacaoDoador = document.getElementById('situacaoDoador').value
    let codFuncionario = document.getElementById('codFuncionario').value

    const dados = {
        nomeDoador: nomeDoador,
        cpfDoador: cpfDoador,
        cnpjDoador: cnpjDoador,
        emailDoador: emailDoador,
        telefoneDoador: telefoneDoador,
        enderecoDoador: enderecoDoador,
        situacaoDoador: situacaoDoador,
        codFuncionario: codFuncionario
    }
    fetch("http://localhost:8080/doador",{
        method: "POST",
        headers:{ "Content-Type":"application/json"},
        body: JSON.stringify(dados)
    })
    .then(resposta => resposta.json())
    .then(dados => {
        console.log(dados)
        res.innerHTML = "Doador cadastrado!"
    })
    .catch((err)=> console.error('Erro ao cadastrar doador: ',err))
})
listaDoadores.addEventListener('click',()=>{
    res2.innerHTML = ""
    fetch("http://localhost:8080/doador")
    .then(resposta => resposta.json())
    .then(dados => {
        res2.innerHTML = "<ul>"
        dados.forEach(valor => {
            res2.innerHTML += "<li>Código: " + valor.codDoador + "&emsp;" +
                              "Nome: " + valor.nomeDoador + "&emsp;" +
                              "CPF: " + valor.cpfDoador + "&emsp;" +
                              "CNPJ: " + valor.cnpjDoador + "&emsp;" +
                              "Email: " + valor.emailDoador + "&emsp;" +
                              "Telefone: " + valor.telefoneDoador + "&emsp;" +
                              "Endereço: " + valor.enderecoDoador + "<br>" +
                              "Situação: " + valor.situacaoDoador + "&emsp;" +
                              "Código do funcionário: " + valor.codFuncionario 
        })
    })
    .catch((err) => console.error("Erro ao listar doadores: ",err))
})
buscaDoador.addEventListener('click',()=>{
    res3.innerHTML = ""
    const idBusca = Number(document.getElementById('codDoadorBusca').value)
    fetch(`http://localhost:8080/doador/${idBusca}`)
    .then(resposta => resposta.json())
    .then(dados => {
        res3.innerHTML += "Código: " + dados.cadDoador + "&emsp;" +
                          "Nome: " + dados.nomeDoador + "&emsp;" +
                          "CPF: " + dados.cpfDoador + "&emsp;" +
                          "CNPJ: " + dados.cnpjDoador + "&emsp;" +
                          "Email: " + dados.emailDoador + "&emsp;" + 
                          "Telefone: " + dados.telefoneDoador + "&emsp;" +
                          "Endereço: " + dados.enderecoDoador + "&emsp;" +
                          "Situação: " + dados.situacaoDoador + "&emsp;" +
                          "Código do funcionário: " + dados.codFuncionario 
    })
    .catch((err)=> console.error("Erro ao buscar doador: ",err))
})
atualizaDoador.addEventListener('click',()=>{
    res4.innerHTML = ""
    const idAtualiza = Number(document.getElementById('codDoadorAtualiza').value)

    const nomeDoador = document.getElementById('nomeDoadorAtualizado').value
    const cpfDoador = document.getElementById('cpfDoadorAtualizado').value
    const cnpjDoador = document.getElementById('cnpjDoadorAtualizado').value
    const emailDoador = document.getElementById('emailDoadorAtualizado').value
    const telefoneDoador = document.getElementById('telefoneDoadorAtualizado').value
    const enderecoDoador = document.getElementById('enderecoDoadorAtualizado').value
    const situacaoDoador = document.getElementById('situacaoDoadorAtualizado').value
    const codFuncionario = document.getElementById('codFuncionarioAtualizado').value

    fetch(`http://localhost:8080/doador/${idAtualiza}`,{
        method: "PUT",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(dados)
    })
    .then(resposta => resposta.json())
    .then(dados => {
        res4.innerHTML = "Dados do doador atualizados!"
    })
    .catch((err)=> console.error("Erro ao atualizar doador: ",err))
})
deletaDoador.addEventListener('click',()=>{
    res5.innerHTML = ""
    const idDeleta = Number(document.getElementById('codDoadorDeleta').value)

    fetch(`http://localhost:8080/doador/${idDeleta}`,{
        method: "DELETE",
        headers: {"Content-Type":"application/json"}
    })
    .then(resposta => resposta.text())
    .then(dados => {
        res5.innerHTML = "Dados do doador apagados!" + "<br>" + "<br>"
    })
    .catch((err)=> console.error("Erro ao apagar doador: ",err))
})

function apareca(option) {
    for(let i=1; i < 6;i++) {
        if(i == option ) {
            document.getElementById(`res${i}`).style.display = 'block'
        }else {
            document.getElementById(`res${i}`).style.display = 'none'
        }
    } 
}