let listaEstoque = document.getElementById('listaEstoque')
let res = document.getElementById('res')

listaEstoque.addEventListener('click',()=>{
    res.innerHTML = ""
    fetch("http://localhost:8080/estoque")
    .then(resposta => resposta.json())
    .then(dados => {
        res.innerHTML = "<ul>"
        dados.forEach(valor => {
            console.log(valor)
            res.innerHTML += "<li>Código: " + valor.codEstoque + "&emsp;" +
                              "Nome: " + valor.nomeProduto + "&emsp;" +
                              "Quantidade: " + valor.quantidadeProduto + "&emsp;" +
                              "Código do produto: " + valor.codProduto + "<br>" + "<br>"
        })
    })
    .catch((err) => console.error("Erro ao listar doadores: ",err))
})

function apareca(option) {
    for(let i=1; i < 6;i++) {
        if(i == option ) {
            document.getElementById(`res${i}`).style.display = 'block'
        }else {
            document.getElementById(`res${i}`).style.display = 'none'
        }
    } 
}