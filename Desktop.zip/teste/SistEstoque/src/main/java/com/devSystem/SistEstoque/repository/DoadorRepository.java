package com.devSystem.SistEstoque.repository;

import com.devSystem.SistEstoque.model.Doador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DoadorRepository extends JpaRepository<Doador,Long> {
}
