let listaEstoque = document.getElementById('listaEstoque')
let res1 = document.getElementById('res1')

listaEstoque.addEventListener('click',()=>{
    res1.innerHTML = ""
    fetch("http://localhost:8080/estoque")
    .then(resposta => resposta.json())
    .then(dados => {
        res1.innerHTML = "<ul>"
        dados.forEach(valor => {
            console.log(valor)
            res1.innerHTML += "<li>Código: " + valor.codEstoque + "&emsp;" +
                              "Nome: " + valor.nomeProduto + "&emsp;" +
                              "Quantidade: " + valor.quantidadeProduto + "&emsp;" +
                              "Código do produto: " + valor.codProduto + "<br>" + "<br>"
        })
    })
    .catch((err) => console.error("Erro ao listar doadores: ",err))
})

function apareca(option) {
    for(let i=1; i < 6;i++) {
        if(i == option ) {
            document.getElementById(`res${i}`).style.display = 'block'
        }else {
            document.getElementById(`res${i}`).style.display = 'none'
        }
    } 
}